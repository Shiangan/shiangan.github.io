from ._codespell import _script_main, main
from ._version import __version__  # type: ignore[import-not-found]

__all__ = ["_script_main", "main", "__version__"]
